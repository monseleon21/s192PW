<div class="container mt-4">
    <div class="card" style="width: 220px; height: 115px; background-image: url('{{ $imagen }}'); background-size: cover; background-position: center; border-radius: 20px;">
        <div class="card-body">
            <p class="card-text" style="color: white; font-size: 1.2rem;">{{ $slot }}</p>
        </div>
    </div>
</div>