<?php

declare(strict_types=1);

return [
    'failed'   => '제출된 인증 정보가 레코드와 일치하지 않습니다.',
    'password' => '비밀번호가 잘못되었습니다.',
    'throttle' => '너무 많은 로그인을 시도하였습니다. :seconds 초 후에 다시 시도하십시오.',
];
