<?php

declare(strict_types=1);

return [
    'next'     => '다음 &raquo;',
    'previous' => '&laquo; 이전',
];
