<?php $__env->startSection('titulo','Formulario'); ?>

<?php $__env->startSection('contenido'); ?>

            

            <div class="container mt-5 col-md-6">

                <?php if(session('exito')): ?>
                  <?php if (isset($component)) { $__componentOriginalb5e767ad160784309dfcad41e788743b = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalb5e767ad160784309dfcad41e788743b = $attributes; } ?>
<?php $component = App\View\Components\Alert::resolve(['tipo' => 'success'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('Alert'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Alert::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?> <?php echo e(session('exito')); ?>  <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalb5e767ad160784309dfcad41e788743b)): ?>
<?php $attributes = $__attributesOriginalb5e767ad160784309dfcad41e788743b; ?>
<?php unset($__attributesOriginalb5e767ad160784309dfcad41e788743b); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalb5e767ad160784309dfcad41e788743b)): ?>
<?php $component = $__componentOriginalb5e767ad160784309dfcad41e788743b; ?>
<?php unset($__componentOriginalb5e767ad160784309dfcad41e788743b); ?>
<?php endif; ?>
                <?php endif; ?>
                
                <?php $__sessionArgs = ['exito'];
if (session()->has($__sessionArgs[0])) :
if (isset($value)) { $__sessionPrevious[] = $value; }
$value = session()->get($__sessionArgs[0]); ?>
                  <?php if (isset($component)) { $__componentOriginalb5e767ad160784309dfcad41e788743b = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalb5e767ad160784309dfcad41e788743b = $attributes; } ?>
<?php $component = App\View\Components\Alert::resolve(['tipo' => 'danger'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('Alert'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Alert::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?> <?php echo e($value); ?>  <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalb5e767ad160784309dfcad41e788743b)): ?>
<?php $attributes = $__attributesOriginalb5e767ad160784309dfcad41e788743b; ?>
<?php unset($__attributesOriginalb5e767ad160784309dfcad41e788743b); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalb5e767ad160784309dfcad41e788743b)): ?>
<?php $component = $__componentOriginalb5e767ad160784309dfcad41e788743b; ?>
<?php unset($__componentOriginalb5e767ad160784309dfcad41e788743b); ?>
<?php endif; ?>
                <?php unset($value);
if (isset($__sessionPrevious) && !empty($__sessionPrevious)) { $value = array_pop($__sessionPrevious); }
if (isset($__sessionPrevious) && empty($__sessionPrevious)) { unset($__sessionPrevious); }
endif;
unset($__sessionArgs); ?>

                <?php $__sessionArgs = ['exito'];
if (session()->has($__sessionArgs[0])) :
if (isset($value)) { $__sessionPrevious[] = $value; }
$value = session()->get($__sessionArgs[0]); ?>
                    <script>
                        Swal.fire({
                            title: "Good job!",
                            text: '<?php echo e($value); ?>',
                             icon: "success"
});
                    </script>
                <?php unset($value);
if (isset($__sessionPrevious) && !empty($__sessionPrevious)) { $value = array_pop($__sessionPrevious); }
if (isset($__sessionPrevious) && empty($__sessionPrevious)) { unset($__sessionPrevious); }
endif;
unset($__sessionArgs); ?>

                <div class="card font-monospace">

                <div class"card-header fs-5 text-center text-primary">
                    <?php echo e(__('Registro de Clientes')); ?>

                </div>
                <div class="card-body text-justify">

                    <form action ="<?php echo e(route('enviaCliente')); ?>" method="POST">
                        <?php echo csrf_field(); ?>

                        <div class="mb-3">
                            <label for="nombre" class="form-label"> <?php echo e(__('Nombre:')); ?> </label>
                            <input type="text" class="form-control" name="txtnombre" value="<?php echo e(old('txtnombre')); ?>">
                            <small class="fst-italic text-danger"><?php echo e($errors->first('txtnombre')); ?></small>
            </div>
            <div class="mb-3">
                <label for"Apellido" class="form-label"> <?php echo e(__('Apellido:')); ?> </label>
                <input type"text" class="form-control" name="txtapellido" value="<?php echo e(old('txtapellido')); ?>">
                <small class="fst-italic text-danger"><?php echo e($errors->first('txtapellido')); ?></small>
            </div>
            <div class="mb-3">
                <label for"correo" class="form-label"><?php echo e(__('Correo:')); ?> </label>
                <input type"text" class="form-control" name="txtcorreo" value="<?php echo e(old('txtcorreo')); ?>">
                <small class="fst-italic text-danger"><?php echo e($errors->first('txtcorreo')); ?></small>    
            </div>         
            <div class="mb-3">
                <label for"telefono" class="form-label"> <?php echo e(__('Telefono:')); ?> </label>
                <input type"text" class="form-control" name="txttelefono"  value="<?php echo e(old('txttelefono')); ?>">  
                <small class="fst-italic text-danger"><?php echo e($errors->first('txttelefono')); ?></small>    
            </div> 
    </div>        

    <div class="card-footer text-muted">

        <div class="d-grid gap-2 mt-2 mb-1">
            <button type="submit" class="btn btn-success btn-sm"> <?php echo e(__('Guardar Cliente')); ?> </button>
        </div>
    </form>

    </div>
    </div>
    </div> 
    

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.plantilla1', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\s192PW\IntroLaravel\resources\views/formulario.blade.php ENDPATH**/ ?>