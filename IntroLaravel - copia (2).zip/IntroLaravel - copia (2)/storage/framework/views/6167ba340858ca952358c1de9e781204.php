<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=, initial-scale=1.0">
    <?php echo app('Illuminate\Foundation\Vite')(['resources/js/app.js']); ?>
    <title>Document</title>
</head>
<body>
    Hola mundo Laravel Proyecto IntroLaravel
</body>
</html>
<?php /**PATH C:\laragon\www\IntroLaravel\resources\views/welcome.blade.php ENDPATH**/ ?>