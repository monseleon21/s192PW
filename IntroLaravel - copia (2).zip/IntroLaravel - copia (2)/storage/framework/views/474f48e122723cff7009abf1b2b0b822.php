<div class="container mt-4">


<div class="alert alert-<?php echo e($tipo); ?>" role="alert"> <?php echo e($slot); ?>

</div>

</div><?php /**PATH C:\laragon\www\s192PW\IntroLaravel\resources\views/components/alert.blade.php ENDPATH**/ ?>