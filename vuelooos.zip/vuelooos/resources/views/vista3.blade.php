<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    @vite(['resources/js/app.js'])
    <title>CRUD Ofertas de Combos</title>
</head>
<body>
    <div class="container mt-5">
        <h1 class="mb-4">Administrar Ofertas de Combos</h1>

        <form id="comboForm" class="mb-4">
            <div class="mb-3">
                <label for="comboName" class="form-label">Nombre del Combo:</label>
                <input type="text" class="form-control" name="comboName">
            </div>

            <div class="mb-3">
                <label for="description" class="form-label">Descripción:</label>
                <textarea class="form-control" name="description" rows="3"></textarea>
            </div>

            <div class="mb-3">
                <label for="discount" class="form-label">Descuento (%):</label>
                <input type="number" class="form-control" name="discount">
            </div>

            <div class="mb-3">
                <label for="validUntil" class="form-label">Válido hasta:</label>
                <input type="date" class="form-control" name="validUntil">
            </div>

            <button type="button" class="btn btn-primary" name="addButton">Guardar Combo</button>
            <button type="button" class="btn btn-secondary" style="display: none;" name="updateButton">Guardar Cambios</button>
        </form>

        <table class="table table-striped">
            <thead>
                <tr>
                    <th>Nombre del Combo</th>
                    <th>Descripción</th>
                    <th>Descuento</th>
                    <th>Válido hasta</th>
                    <th>Acciones</th>
                </tr>
            </thead>
            <tbody id="combosTable">
            </tbody>
        </table>
    </div>

</body>
</html>
